import os
import re
import ast
import json
import time
import threading
from typing import Dict, Any
from django.conf import settings
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
from django.db import connections
from django.core.cache import caches
import copy
import hvac

# ----- Constants -----
SETTINGS_FILE_PATH = os.path.abspath(
    os.path.join(os.path.dirname(__file__), "..", "my_django_project", "settings.py")
)

# ----- Constants -----
VAULT_URL = os.environ.get("VAULT_URL", "http://vault.vault-devsecops.svc.cluster.local:8200")
VAULT_ROLE = os.environ.get("VAULT_ROLE", "myapp-role")
VAULT_PATH = "myapp/config"
TOKEN_FILE = "/var/run/secrets/kubernetes.io/serviceaccount/token"
POLL_INTERVAL = int(os.environ.get("VAULT_POLL_INTERVAL", 30))

SECRET_FILE = "myapp/config"


# ----- Globals -----
OLD_SECRETS: Dict[str, Any] = {}

# ----- Helper Functions -----
def extract_settings_with_env() -> Dict[str, Any]:
    """
    Parse settings.py and extract variables using os.getenv()
    """
    env_line_pattern = re.compile(r'^\s*([A-Z_][A-Z0-9_]*)\s*=\s*(os\.getenv\([^)]+\))')
    block_start_pattern = re.compile(r'^([A-Z_][A-Z0-9_]*)\s*=\s*{\s*$')
    getenv_pattern = re.compile(r'os\.getenv\([^)]+\)')

    seen_keys = set()
    parsed_settings = {}

    with open(SETTINGS_FILE_PATH, "r", encoding="utf-8") as f:
        lines = f.readlines()

    i = 0
    while i < len(lines):
        line = lines[i]

        # Handle single-line os.getenv
        match = env_line_pattern.match(line)
        if match:
            key, expr = match.groups()
            if key not in seen_keys:
                parsed_settings[key] = _replace_getenv_with_secret(expr)
                seen_keys.add(key)
            i += 1
            continue

        # Handle multi-line blocks
        block_match = block_start_pattern.match(line)
        if block_match:
            key = block_match.group(1)
            block_lines = ["{"]
            brace_depth = 1
            i += 1

            while i < len(lines) and brace_depth > 0:
                block_line = lines[i]
                brace_depth += block_line.count("{") - block_line.count("}")
                block_lines.append(block_line.rstrip())
                i += 1

            full_block = "\n".join(block_lines)
            if getenv_pattern.search(full_block) and key not in seen_keys:
                parsed_settings[key] = _replace_getenv_with_secret(full_block)
                seen_keys.add(key)
            continue

        i += 1

    return parsed_settings


def _replace_getenv_with_secret(expr: str) -> Any:
    """
    Replace os.getenv(...) with secrets.get(...) and try to evaluate safely.
    """
    try:
        expr = re.sub(r'os\.getenv\(([^)]+)\)', r'secrets.get(\1)', expr)
        return ast.literal_eval(expr)
        print(_replace_getenv_with_secret(expr))
    except Exception:
        return expr  # Return as string expression if evaluation fails

def deep_compare(a: Any, b: Any) -> bool:
    """
    Recursively compare two JSON-like structures.
    """
    if type(a) != type(b):
        return False
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(deep_compare(a[k], b[k]) for k in a)
    if isinstance(a, list):
        return len(a) == len(b) and all(deep_compare(i, j) for i, j in zip(a, b))
    return a == b


def deep_merge(d1: Dict[Any, Any], d2: Dict[Any, Any]) -> None:
    for k, v in d2.items():
        if (
            k in d1
            and isinstance(d1[k], dict)
            and isinstance(v, dict)
        ):
            deep_merge(d1[k], v)
        else:
            d1[k] = v

def get_secrets_from_vault() -> Dict[str, Any]:
    """
    Retrieve secrets from Vault.
    """
    try:
        with open(TOKEN_FILE, "r") as f:
                jwt = f.read().strip()

                client = hvac.Client(url=VAULT_URL)
                client.auth.kubernetes.login(role=VAULT_ROLE, jwt=jwt)

                if not client.is_authenticated():
                    raise Exception("Vault authentication failed")

                response = client.secrets.kv.v2.read_secret_version(path=VAULT_PATH)
                return response['data']['data']
    except Exception as e:
        print(f"Failed to load secrets from Vault: {e}")



def reload_if_needed():
    """Check for updates in Vault and reload settings if needed."""
    global OLD_SECRETS
    while True:
        secrets = get_secrets_from_vault()
        if deep_compare(secrets, OLD_SECRETS):
            print("No changes detected in secrets.")
        else:
            print("Secrets updated. Reloading Django settings...")
            OLD_SECRETS = secrets.copy()
            SETTINGS_MAP = extract_settings_with_env()
            print(f"Done for SETTINGS_MAP: {SETTINGS_MAP}")
            safe_globals = {'secrets': secrets}
            for key, expr in SETTINGS_MAP.items():
                print(f"loop started {key} to {expr}")
                try:
                    value = eval(expr, safe_globals)

                    if isinstance(value, dict) and hasattr(settings, key):
                        existing = getattr(settings, key)
                        if isinstance(existing, dict):
                            deep_merge(existing, value)
                            setattr(settings, key, existing)
                            if key == "DATABASES":
                                connections.close_all()
                                print(f"{key} updated and DB connections reset.")
                    else:
                        setattr(settings, key, value)
                        print(f"{key} set to new value.")
                except Exception as e:
                    print(f"Failed to set {key}: {e}")

        time.sleep(POLL_INTERVAL)

# ----- Watcher -----
def start_vault_poller():
    """Start the vault poller in a separate thread."""
    t = threading.Thread(target=reload_if_needed, daemon=True)
    t.start()
    print("Vault poller started.")

# ----- Entry Point -----
if __name__ == "__main__":
    start_vault_poller()
    # Keep the main thread alive to allow the poller to run
    while True:
        time.sleep(1)
