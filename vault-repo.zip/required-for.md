✅ Vault + CSI Driver Setup Without Secret Sync on Minikube
________________________________________
1. Start Minikube (without any storage addons)
bash
CopyEdit
minikube start
________________________________________
2. Add Helm repos and update
helm repo add hashicorp https://helm.releases.hashicorp.com
helm repo add secrets-store-csi-driver https://kubernetes-sigs.github.io/secrets-store-csi-driver/charts
helm repo update
________________________________________
3. Create namespace
kubectl create namespace vault-devsecops
________________________________________
4. Install Vault in dev mode (for testing)
helm install vault hashicorp/vault \
  -n vault-devsecops \
  --version 0.20.0 \
  --set "ui.enabled=true" \
  --set "ui.serviceType=NodePort" \
  --set "server.dev.enabled=true"
________________________________________
5. Port-forward to access Vault UI
kubectl port-forward svc/vault -n vault-devsecops 8200:8200
Open http://localhost:8200 and login with root token
________________________________________
6. Setup Vault policy and secrets inside Vault pod
kubectl exec -it -n vault-devsecops vault-0 -- sh
vault login root
 
# Create new policy file
cat <<EOF > /home/vault/devsecops-policy.hcl
path "secret/data/myapp/config" {
  capabilities = ["read"]
}
EOF
 
# Apply the policy
vault policy write myapp-policy /home/vault/devsecops-policy.hcl
 
# Enable secrets engine if not already
vault secrets enable -path=secret kv-v2
# Add secrets
vault kv put secret/myapp/config username="admin" password="s3cr3t!"
________________________________________
7. Enable Kubernetes auth and configure
vault auth enable kubernetes

vault write auth/kubernetes/config 
token_reviewer_jwt="$(cat /var/run/secrets/kubernetes.io/serviceaccount/token)" 
kubernetes_host="https://$KUBERNETES_PORT_443_TCP_ADDR" 
kubernetes_ca_cert=@/var/run/secrets/kubernetes.io/serviceaccount/ca.crt


exit
________________________________________
8. Create K8s Service Account
yaml
CopyEdit
apiVersion: v1
kind: ServiceAccount
metadata:
  name: myapp-sa
  namespace: vault-devsecops
bash
CopyEdit
kubectl apply -f service-account.yaml
________________________________________
9. Create Vault Kubernetes auth role
kubectl exec -it -n vault-devsecops vault-0 – sh

vault write auth/kubernetes/role/myapp-role 
bound_service_account_names=myapp-sa 
bound_service_account_namespaces=vault-devsecops 
policies=myapp-policy 
ttl=24h