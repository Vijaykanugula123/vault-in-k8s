from django.http import JsonResponse
from django.db import connection
from django.conf import settings
def test(request):
    try:
        print(f"the settings variable{settings.MY_SEC_URL}")
        print(f"The nested settings variable: {settings.DATABASES1['default1']['key1']['key2']['key3']['key4']['key5']}")
        with connection.cursor() as cursor:
            cursor.execute("SELECT * FROM sample_data")
            columns = [col[0] for col in cursor.description]
            data = [dict(zip(columns, row)) for row in cursor.fetchall()]
        return JsonResponse({"data": data})
    except Exception as e:
        import traceback
        return JsonResponse({"error": str(e), "trace": traceback.format_exc()})
